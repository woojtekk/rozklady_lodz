# Rozklady Lodz for Home Assistant

This folder contains the actual custom component that surfaces Łódź realtime departures as sensors. End-user installation and configuration instructions now live in the repository-level `README.md`, so refer to that document for details.
asdasdsa
